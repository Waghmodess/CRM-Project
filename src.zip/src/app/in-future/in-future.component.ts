import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-in-future',
  templateUrl: './in-future.component.html',
  styleUrls: ['./in-future.component.css']
})
export class InFutureComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
