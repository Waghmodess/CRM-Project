import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { DataService } from '../data.service';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
  // public formvalue: any
  public data: any;
  public myForm: any;

  constructor(private ser: DataService, private fb: FormBuilder, private route: Router) {
    this.ser.setMassage().subscribe((res) => {
      console.log(res)
      this.data = res;
    })
  }

  ngOnInit(): void {
    this.myForm = this.fb.group({
      name: [this.data.name],
      age: [this.data.age],
      empId: [this.data.empId],
      branch: [this.data.branch],
      role: [this.data.role]
    })
  }

  onSubmit() {
    console.log(this.myForm.value)
    this.ser.editData(this.data.id, this.myForm.value).subscribe((res) => {
      console.log(res);
      this.route.navigate(['/landing']);
    })
  }
}
