import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-closed',
  templateUrl: './closed.component.html',
  styleUrls: ['./closed.component.css']
})
export class ClosedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
