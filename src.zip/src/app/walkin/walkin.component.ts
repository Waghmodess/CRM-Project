import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-walkin',
  templateUrl: './walkin.component.html',
  styleUrls: ['./walkin.component.css']
})
export class WalkinComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
