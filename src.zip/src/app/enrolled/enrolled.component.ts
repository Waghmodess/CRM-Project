import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-enrolled',
  templateUrl: './enrolled.component.html',
  styleUrls: ['./enrolled.component.css']
})
export class EnrolledComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
