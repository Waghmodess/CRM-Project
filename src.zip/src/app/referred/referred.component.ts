import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-referred',
  templateUrl: './referred.component.html',
  styleUrls: ['./referred.component.css']
})
export class ReferredComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
