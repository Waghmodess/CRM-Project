import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-re-enquried',
  templateUrl: './re-enquried.component.html',
  styleUrls: ['./re-enquried.component.css']
})
export class ReEnquriedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
